<footer class="main-footer">
  <strong>Copyright &copy; <script>document.write(new Date().getFullYear());</script> <a href="http://code4berry.com">Jayash</a>.</strong>
  All rights reserved.
</footer>